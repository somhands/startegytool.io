// import React from 'react';

// const Platform = ({disabled}) => {
//   return <>
//        <li
//               key={e.id}
//               className="nav-item fontss"
//               data-bs-toggle="tooltip"
//               data-bs-placement="right"
              
//               title={channel}
              
//             >
//               <p
//                 to={`/${channel}`}
//                 className="nav-link"
//                 data-bs-target={`#${channel}`}
//                 onClick={() => clickHandler(channel)}
//               >
//                 <img src={`http://localhost:1337${
//                             icon["data"]["attributes"]["url"]}`} style={{height:"2vh" , marginRight:"5px"}}></img>  

//                 {/* <img src={Facebook}></img> */}
//                 {channel}
//               </p>
//             </li>
//   </>;
// };

// export default Platform;
