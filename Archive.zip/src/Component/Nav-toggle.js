import React from "react";

const Nav_toggle = () => {
  return (
    <div>
      <div className="nav-toggle-box">
        <div className="top-navbar d-none d-xl-block">
          <h4>Logo</h4>
        </div>
      </div>
    </div>
  );
};

export default Nav_toggle;
